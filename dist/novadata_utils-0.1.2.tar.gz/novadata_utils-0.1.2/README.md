# novadata utils
Pacote para facilitar o seu dia a dia como programador Django.

## Getting Started

### Dependências
Django
Django Rest Framework

#### Installation
```shell
pip install novadata-utils
```

Settings.py:
```python
INSTALLED_APPS = [
    ...
    'novadata_utils',
    ...
]
```


## Features
