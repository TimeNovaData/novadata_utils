from .novadata_model_serializer import NovadataModelSerializer

__all__ = [
    NovadataModelSerializer,
]
