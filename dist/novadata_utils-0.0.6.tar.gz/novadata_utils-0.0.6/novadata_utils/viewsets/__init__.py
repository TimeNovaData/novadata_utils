from .novadata_model_viewset import NovadataModelViewSet

__all__ = [
    NovadataModelViewSet,
]
