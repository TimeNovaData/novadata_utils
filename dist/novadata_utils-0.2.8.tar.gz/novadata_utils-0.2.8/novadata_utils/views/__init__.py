from .novadata_view import NovadataView

__all__ = [
    NovadataView,
]
