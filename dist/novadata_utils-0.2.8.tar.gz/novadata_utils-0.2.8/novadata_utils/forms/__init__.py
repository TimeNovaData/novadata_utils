from .gerenciar_inline_form import gerenciar_inline_form

__all__ = [
    gerenciar_inline_form,
]
