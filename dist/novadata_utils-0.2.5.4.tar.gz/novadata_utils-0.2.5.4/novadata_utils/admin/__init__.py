from .novadata_model_admin import NovadataModelAdmin

__all__ = [
    NovadataModelAdmin,
]
