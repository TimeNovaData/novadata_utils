from .base_site import BasePageView
from .novadata_view import NovadataView

__all__ = [
    BasePageView,
    NovadataView,
]
