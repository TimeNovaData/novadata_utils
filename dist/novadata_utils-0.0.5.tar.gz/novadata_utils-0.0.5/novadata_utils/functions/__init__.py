from .get_prop import get_prop

__all__ = [
    get_prop,
]
