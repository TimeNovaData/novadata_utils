from .novadata_model import NovadataModel

__all__ = [
    NovadataModel,
]
